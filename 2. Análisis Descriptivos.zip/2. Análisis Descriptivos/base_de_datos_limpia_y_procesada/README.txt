INSTRUCCIONES:

1. Asegúrate de tener Python instalado en tu computadora.
2. Instala la biblioteca necesaria si no la tienes:
   pip install pandas

3. Coloca este archivo junto al archivo SQL llamado 'peliculas_40k_limpias.sql'.
4. Ejecuta el script:
   python corregir_datos_repetidos_actuales.py

5. El archivo corregido se llamará 'Cinemetrix.sql' y estará listo para ser importado en MySQL Workbench.
